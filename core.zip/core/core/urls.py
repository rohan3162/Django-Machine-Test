# api/urls.py
from django.urls import path
from home.views import UserListCreate, ClientListCreate, ClientRetrieveUpdateDestroy, ProjectListCreate, ProjectRetrieveUpdateDestroy, ClientRegister, CustomTokenObtainPairView, UserRegistrationView
urlpatterns = [
    path('users/', UserListCreate.as_view(), name='user-list-create'),
    path('clients/', ClientListCreate.as_view(), name='client-list-create'),
    path('clients/<int:pk>/', ClientRetrieveUpdateDestroy.as_view(), name='client-retrieve-update-destroy'),
    path('clients/register/', ClientRegister.as_view(), name='client-register'),
    path('projects/', ProjectListCreate.as_view(), name='project-list-create'),
    path('projects/<int:pk>/', ProjectRetrieveUpdateDestroy.as_view(), name='project-retrieve-update-destroy'),
    path('login/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('register/', UserRegistrationView.as_view(), name='user-registration'),
]
